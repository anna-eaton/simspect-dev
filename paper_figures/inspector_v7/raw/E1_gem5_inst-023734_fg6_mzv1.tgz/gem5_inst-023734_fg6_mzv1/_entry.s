.global _start
.section .text
_start:
    call "inst-023734"
    mov $60, %rax
    xor %rdi, %rdi
    syscall
