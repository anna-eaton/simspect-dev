.global _start
.section .text
_start:
    call "inst-014536"
    mov $60, %rax
    xor %rdi, %rdi
    syscall
