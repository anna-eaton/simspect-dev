.global _start
.section .text
_start:
    call "inst-000125"
    mov $60, %rax
    xor %rdi, %rdi
    syscall
